import * as aoc2015 from './2015/2015.js'
import * as aoc2022 from './2022/2022.js'
import * as aoc2023 from './2023/2023.js'
import * as aoc2024 from './2024/2024.js'
import * as aoc2025 from './2025/2025.js'

// aoc2015.run()
// aoc2022.run()
// aoc2023.run()
// aoc2024.run()
aoc2025.run()