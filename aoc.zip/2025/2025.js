// import day1 from "./day1/run.js";
import day2 from "./day2/run.js";

function run() {
  // day1.execute();
  day2.execute();
}

export { run };
