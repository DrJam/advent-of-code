import day1 from "./day-1/day-1.js";
import day2 from "./day-2/day-2.js";
import day3 from "./day-3/day-3.js";
import day4 from "./day-4/day-4.js";
import day5 from "./day-5/day-5.js";
import day6 from "./day-6/day-6.js";
import day7 from "./day-7/day-7.js";
import day8 from "./day-8/day-8.js";
import day9 from "./day-9/day-9.js";
import day10 from "./day-10/day-10.js";
import day11 from "./day-11/day-11.js";
import day12 from "./day-12/day-12.js";

function run() {
    // day1.execute()
    // day2.execute()
    // day3.execute()
    // day4.execute()
    // day5.execute()
    // day6.execute()
    // day7.execute()
    // day8.execute()
    // day9.execute()
    // day10.execute()
    // day11.execute()
    day12.execute()
}

export { run }