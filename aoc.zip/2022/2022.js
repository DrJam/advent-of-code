import day1 from "./day1/day1.js";
import day10 from "./day10/day10.js";
import day11 from "./day11/day11.js";
import day12 from "./day12/day12.js";
import day13 from "./day13/day13.js";
import day14 from "./day14/day14.js";
import day15 from "./day15/day15.js";
import day16 from "./day16/day16.js";
import day17 from "./day17/day17.js";
import day18 from "./day18/day18.js";
import day19 from "./day19/day19.js";
import day2 from "./day2/day2.js";
import day20 from "./day20/day20.js";
import day21 from "./day21/day21.js";
import day22 from "./day22/day22.js";
import day23 from "./day23/day23.js";
import day24 from "./day24/day24.js";
import day25 from "./day25/day25.js";
import day3 from "./day3/day3.js";
import day4 from "./day4/day4.js";
import day5 from "./day5/day5.js";
import day6 from "./day6/day6.js";
import day7 from "./day7/day7.js";
import day8 from "./day8/day8.js";
import day9 from "./day9/day9.js";

function run() {
    // day1.execute()
    // day2.execute()
    // day3.execute()
    // day4.execute()
    // day5.execute()
    // day6.execute()
    // day7.execute()
    // day8.execute()
    // day9.execute()
    // day10.execute()
    // day11.execute()
    day12.execute()
    // day13.execute()
    // day14.execute()
    // day15.execute()
    // day16.execute()
    // day17.execute()
    // day18.execute()
    // day19.execute()
    // day20.execute()
    // day21.execute()
    // day22.execute()
    // day23.execute()
    // day24.execute()
    // day25.execute()
}

export { run }