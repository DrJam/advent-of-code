import day1 from "./day1/day1.js";
function run() {
    day1.execute()
}

export { run }